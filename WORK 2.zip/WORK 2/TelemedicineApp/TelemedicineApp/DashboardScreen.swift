//
//  DashboardScreen.swift
//  TelemedicineApp
//
//  Created by admin on 15/02/25.
//

import SwiftUI



class DashbordScreenViewModel{
    
    let doctors: [String : String] = [:]
    
   
    
}

struct DashboardScreen: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct DashboardScreen_Previews: PreviewProvider {
    static var previews: some View {
        DashboardScreen()
    }
}
