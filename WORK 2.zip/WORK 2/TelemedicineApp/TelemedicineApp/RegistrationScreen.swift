//
//  RegistrationScreen.swift
//  TelemedicineApp
//
//  Created by admin on 15/02/25.
//

import SwiftUI

struct RegistrationScreen: View {
    
    @State var email : String = ""
    @State var password: String = ""
    @State var phoneNumber: String = ""
    
    var body: some View {
          NavigationView {
            
            VStack{
                
                TextField("Phone Number", text: $phoneNumber)
                
                TextField("Email", text: $email)
                
                TextField("Password", text: $password)
                
                Button("Register") {
                    RegistrationScreen()
                }.bold()
                    .foregroundColor(.white)
                .frame(width: 100, height: 40)
                    .background(Color(.blue))
                   
                
            }.padding(20)
            
          
        }.navigationTitle("Registration")

      }
}

struct RegistrationScreen_Previews: PreviewProvider {
    static var previews: some View {
        RegistrationScreen()
    }
}
