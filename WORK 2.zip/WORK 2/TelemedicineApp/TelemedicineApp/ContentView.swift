//
//  ContentView.swift
//  TelemedicineApp
//
//  Created by admin on 15/02/25.
//

import SwiftUI
import CoreData

class ContentViewModel{
    
   
    
}

struct ContentView: View {
   
    @State var email : String = ""
    @State var password: String = ""

    var body: some View {
        NavigationView {
            
            VStack{
                
                TextField("Email", text: $email)
                
                TextField("Password", text: $password)
                Spacer()
                
                Button("LOGIN") {
                    RegistrationScreen()
                }.bold()
                    .foregroundColor(.white)
                    .frame(width: 100, height: 40)
                    .background(Color(.blue))
                   
                
            }.navigationTitle("Login ")
            
          
        }

  
   
    }
}



struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
