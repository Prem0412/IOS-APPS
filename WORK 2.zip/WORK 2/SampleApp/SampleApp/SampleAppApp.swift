//
//  SampleAppApp.swift
//  SampleApp
//
//  Created by admin on 26/01/25.
//

import SwiftUI

@main
struct SampleAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
