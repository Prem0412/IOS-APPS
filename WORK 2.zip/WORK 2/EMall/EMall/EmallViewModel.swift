//
//  EmallViewModel.swift
//  EMall
//
//  Created by admin on 03/02/25.
//

import Foundation
import CoreData

class EmallViewModel: ObservableObject{
    let container: NSPersistentContainer
    @Published var savedOrders : [OrderEntity] = []
    @Published var categoryArray: [String] = ["Vegetables","Fruits","Electronics","Clothes"]
    
    init()
    {
        container = NSPersistentContainer(name: "OrderContainer")
        container.loadPersistentStores
        { NSEntityDescription, error in
            if let error = error {  print("Error occured while loading container...\(error)")   }
            else{   print("Core Data successfully loaded!") }
        }
        fetchOrder()
    }
    
    func fetchOrder()
    {
        let request = NSFetchRequest<OrderEntity>(entityName: "OrderEntity")
        do{  savedOrders = try container.viewContext.fetch(request)
        }catch let error{
            print("Error while frtching container data...\(error)")
        }
        
    }
    
    func addOrder(category:String, amount:String, name:String, quantity:String)
    {
        let newOrder = OrderEntity(context : container.viewContext)
        newOrder.name = name
        newOrder.amount = amount
        newOrder.category = category
        newOrder.quantity = quantity
        
        saveData()
    }
    
    func saveData(){
        do{try container.viewContext.save()}
        catch let error { print("Error while saving data!..\(error)") }
    }
    
    func deleteOrder(){
        
    }
}
