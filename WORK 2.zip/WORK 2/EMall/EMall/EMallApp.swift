//
//  EMallApp.swift
//  EMall
//
//  Created by admin on 03/02/25.
//

import SwiftUI

@main
struct EMallApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
