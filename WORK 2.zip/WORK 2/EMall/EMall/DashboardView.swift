//
//  DashboardView.swift
//  EMall
//
//  Created by admin on 03/02/25.
//

import SwiftUI





struct DashboardView: View {
    @StateObject var viewModel: EmallViewModel = EmallViewModel()
    var body: some View {
        NavigationView{
            
            VStack(){
                Text("WELCOME!")
                    .font(.system(size: 25))
                    .foregroundColor(.green)
                    .bold()
                    .padding()
                
                Text("Your order history is here")
                    .font(.system(size: 20))
                    .foregroundColor(.green)
                List{
                  /*  ForEach(viewModel.savedOrders) { order in
                       Text( "\(order.name)")
                    }*/
                }
                Button("ADD ORDER") {
                    PlaceOrderVIew()
                    
                }
            }.padding()
            .navigationTitle("Dashboard")
        }.environmentObject(viewModel)
    }
}

struct DashboardView_Previews: PreviewProvider {
    static var previews: some View {
        DashboardView()
    }
}
