//
//  PlaceOrderVIew.swift
//  EMall
//
//  Created by admin on 03/02/25.
//

import SwiftUI

struct PlaceOrderVIew: View {
    @EnvironmentObject var viewModel:EmallViewModel
    
    @State var category:String = ""
    @State var name:String = ""
    @State var amount:String = ""
    @State var quantity:String = ""
    var body: some View {
        NavigationView{
            VStack{
                TextField("Category", text: $category)
                TextField("Name", text: $name)
                TextField("Quantity", text: $quantity)
                TextField("Amount", text: $amount)
                Spacer()
                Button("Place Order")
                {
                    viewModel.addOrder(category: category, amount: amount, name: name, quantity: quantity)
                }.bold()
                    .foregroundColor(.black)
                .frame(width: 200, height:50)
                .cornerRadius(30)
                .background(Color(.green))
            }.padding(10)
            .navigationTitle("Place Order")
           
           
        }
    }
}

struct PlaceOrderVIew_Previews: PreviewProvider {
    static var previews: some View {
        PlaceOrderVIew()
    }
}
