//
//  TransactionViewModel.swift
//  BudgetTracker-3
//
//  Created by admin on 30/01/25.
//

/*import Foundation
struct Transaction: Identifiable {
    let id = UUID()
    var title: String
    var amount: Double
    var type: TransactionType

    enum TransactionType: String, CaseIterable, Identifiable {
        case income = "Income"
        case expense = "Expense"

        var id: String { rawValue } //".income, .expense"
    }
}

// ViewModel for Transactions
class TransactionViewModel: ObservableObject {
    //@Environment(\.managedObjectContext) private var viewContext

    
   @Published var transactions: [Transaction] = []
  

    var balance: Double {
        let income = transactions.filter { $0.type == .income }.map { $0.amount }.reduce(0, +)
        let expenses = transactions.filter { $0.type == .expense }.map { $0.amount }.reduce(0, +)
        return income - expenses
    }

    var totalIncome: Double {
        transactions.filter { $0.type == .income }.map { $0.amount }.reduce(0, +)
    }

    var totalExpenses: Double {
        transactions.filter { $0.type == .expense }.map { $0.amount }.reduce(0, +)
    }

    func addTransaction(_ transaction: Transaction) {
        transactions.append(transaction)
    }

    func deleteTransaction(at offsets: IndexSet) {
        transactions.remove(atOffsets: offsets)
    }

    func updateTransaction(_ transaction: Transaction, at index: Int) {
        transactions[index] = transaction
    }
}
*/
import Foundation
import CoreData

class TransactionViewModel: ObservableObject {
    private let viewContext: NSManagedObjectContext

    @Published var transactions: [TransactionEntity] = []

    init(context: NSManagedObjectContext) {
        self.viewContext = context
        fetchTransactions()
    }

    func fetchTransactions() {
        let request: NSFetchRequest<TransactionEntity> = TransactionEntity.fetchRequest()
        do {
            transactions = try viewContext.fetch(request)
        } catch {
            print("Error fetching transactions: \(error.localizedDescription)")
        }
    }

    var balance: Double {
        let income = transactions.filter { $0.type == "Income" }.map { $0.amount }.reduce(0, +)
        let expenses = transactions.filter { $0.type == "Expense" }.map { $0.amount }.reduce(0, +)
        return income - expenses
    }

    var totalIncome: Double {
        transactions.filter { $0.type == "Income" }.map { $0.amount }.reduce(0, +)
    }

    var totalExpenses: Double {
        transactions.filter { $0.type == "Expense" }.map { $0.amount }.reduce(0, +)
    }

    func addTransaction(title: String, amount: Double, type: String) {
        let newTransaction = TransactionEntity(context: viewContext)
        newTransaction.id = UUID()
        newTransaction.title = title
        newTransaction.amount = amount
        newTransaction.type = type

        saveContext()
    }

    func deleteTransaction(_ transaction: TransactionEntity) {
        viewContext.delete(transaction)
        saveContext()
    }

    func updateTransaction(_ transaction: TransactionEntity, title: String, amount: Double, type: String) {
        transaction.title = title
        transaction.amount = amount
        transaction.type = type
        saveContext()
    }

    private func saveContext() {
        do {
            try viewContext.save()
            fetchTransactions()
        } catch {
            print("Error saving context: \(error.localizedDescription)")
        }
    }
}

