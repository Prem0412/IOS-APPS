//
//  TransactionFormView.swift
//  BudgetTracker-3
//
//  Created by admin on 30/01/25.
//

import SwiftUI
import CoreData

struct TransactionFormView: View {
    @Environment(\.presentationMode) private var presentationMode
    @Environment(\.managedObjectContext) private var viewContext
    
    @FetchRequest(entity: TransactionEntity.entity(), sortDescriptors: [])
    
  private var transaction: FetchedResults<TransactionEntity>
    
    @State private var title: String = ""
    @State private var amount: String = ""
    @State private var type: String = "Expense"

   // var transaction: TransactionEntity?
    
    var transactionIndex: Int?

    var body: some View {
        
        NavigationView{
        VStack {
            Form {
                Section(header: Text("Transaction Details"))
                {
                    TextField("Title", text: $title)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    TextField("Amount", text: $amount)
                        .keyboardType(.decimalPad)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    Picker("Type", selection: $type)
                    {
                        Text("Income").tag("Income")
                        Text("Expense").tag("Expense")
                    }
                }
                    .pickerStyle(SegmentedPickerStyle())
                }
            }
            
            Button(action: saveTransaction) {
                Text(transaction != nil ? "Update Transaction" : "Add Transaction")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
            .padding()
        }.onAppear {
            loadTransactionData()
        }
        .navigationTitle(transaction != nil ? "Edit Transaction" : "Add Transaction")
    }

    
    private func saveTransaction() {
        guard let amountValue = Double(amount) else { return }
        
        if let  transaction =  transaction
        {
             Update existing transaction
            transaction.title = title
            transaction.amount = amountValue
           transaction.type = type
        } else {
            // Create a new transaction
            let newTransaction = TransactionEntity(context: viewContext)
            newTransaction.id = UUID()
            newTransaction.title = title
            newTransaction.amount = amountValue
            newTransaction.type = type
        }
        
        do {
            try viewContext.save()
            presentationMode.wrappedValue.dismiss()
        } catch {
            print("Failed to save transaction: \(error.localizedDescription)")
        }
    }
    
    private func loadTransactionData() {
        if let transaction = transaction {
            title = transaction.title ?? ""
            amount = String(transaction.amount)
            type = transaction.type ?? "Expense"
        }
    }
}

/*

import SwiftUI
import CoreData

struct TransactionFormView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.presentationMode) private var presentationMode
    @FetchRequest(
        entity:TransactionEntity.entity(),
        sortDescriptors: []
    )
    //@ObservedObject var viewModel: TransactionViewModel
     
   private var transaction: FetchedResults<TransactionEntity>
     
    @State private var title: String = ""
    @State private var amount: String = ""
    @State private var type: String = "Expense"
    
   // var transaction: TransactionEntity?
    
    var body: some View {
        VStack {
            Form {
                Section(header: Text("Transaction Details")) {
                    TextField("Title", text: $title)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    TextField("Amount", text: $amount)
                        .keyboardType(.decimalPad)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    Picker("Type", selection: $type) {
                        Text("Income").tag("Income")
                        Text("Expense").tag("Expense")
                    }
                    .pickerStyle(SegmentedPickerStyle())
                }
            }
            
            Button(action: saveTransaction) {
                Text(transaction != nil ? "Update Transaction" : "Add Transaction")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
            .padding()
        }
        .onAppear {
            loadTransactionData()
        }
        .navigationTitle(transaction != nil ? "Edit Transaction" : "Add Transaction")
    }
    
    private func saveTransaction() {
        guard let amountValue = Double(amount) else { return }
        
        if let transaction = transaction{
            // Update existing transaction
            transaction.title = title
            transaction.amount = amountValue
            transaction.type = type
        } else {
            // Create a new transaction
            let newTransaction = TransactionEntity(context: viewContext)
            newTransaction.id = UUID()
            newTransaction.title = title
            newTransaction.amount = amountValue
            newTransaction.type = type
        }
        
        do {
            try viewContext.save()
            presentationMode.wrappedValue.dismiss()
        } catch {
            print("Failed to save transaction: \(error.localizedDescription)")
        }
    }
    
    private func loadTransactionData() {
        if let transaction = transaction {
            title = transaction.title ?? ""
            amount = String(transaction.amount)
            type = transaction.type ?? "Expense"
        }
    }
}
*/
