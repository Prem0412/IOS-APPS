//
//  BudgetTracker_3App.swift
//  BudgetTracker-3
//
//  Created by admin on 30/01/25.
//

import SwiftUI

@main
struct BudgetTracker_3App: App {
    let persistentController = PersistenceController.shared
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistentController.container.viewContext)
        }
    }
}
