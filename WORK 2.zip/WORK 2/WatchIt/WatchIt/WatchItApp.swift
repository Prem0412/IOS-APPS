//
//  WatchItApp.swift
//  WatchIt
//
//  Created by admin on 30/01/25.
//

import SwiftUI

@main
struct WatchItApp: App {
    var body: some Scene {
        WindowGroup {
           // ContentView()
            MovieList()
        }
    }
}
