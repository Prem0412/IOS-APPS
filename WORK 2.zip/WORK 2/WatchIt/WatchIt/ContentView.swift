//
//  ContentView.swift
//  WatchIt
//
//  Created by admin on 30/01/25.
//

import SwiftUI

struct ContentView: View {
    @State var userName: String = ""
    @State var password: String = ""
    var body: some View {
        NavigationView
        {
            VStack{
                Text("LOGIN").font(.system(size: 20)).bold()
                HStack {
                    
                    Text("User Name : ")
                    TextField("UserName",text: $userName)
                }
                .padding()
                
                HStack {
                    
                    Text("Password : ")
                    TextField("Password",text: $password)
                    
                          }
                .padding()
                
               
                
               
            }
            .navigationTitle("Login ")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
