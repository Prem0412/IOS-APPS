//
//  MovieList.swift
//  WatchIt
//
//  Created by admin on 30/01/25.
//

import SwiftUI
import CoreData



class MovieViewModel: ObservableObject
{
    
    // creating container for data
    let container : NSPersistentContainer
    
    // array to  save movies
    @Published var savedMoviesArray: [MovieET] = []
    
    // initializing data container
    init()
    {
        container = NSPersistentContainer(name : "MovieEntity")
        
        // checking if container is loaded or not
        container.loadPersistentStores
        {( description, error) in
            if let error = error
            {print("Error loading CoreData : \(error)")}
                else{ print("Successfully loaded core data!")}
        }
        
        
    }
    // requesting to fetch data of container
    func fetchMovie()
    {
        let request = NSFetchRequest<MovieET>(entityName: "MovieET")
        do{  savedMoviesArray = try
            container.viewContext.fetch(request)
        }catch let error{
            print("ERROR FETCHING...\(error)")
        }
    }
    
    
    //function to add movie
    func addMovie(movieName:String){
        let newMovie = MovieET(context: container.viewContext)
        newMovie.name = movieName
        saveData()  // To save new movie data into container/DB
        
    }
    // FUNCTION TO DELETE MOVIE
    func deleteMovie(indexSet:IndexSet){
        guard let index = indexSet.first else {return}
        
        let selectedMovie = savedMoviesArray[index]
        container.viewContext.delete(selectedMovie)
        saveData()
    }
    
    func saveData(){
        do{
            try container.viewContext.save()
            fetchMovie()    // to load saved movie into data
        }catch let error{
            print("ERROR SAVING...\(error)")
        }
    }
}

struct MovieList: View {
    
    @StateObject var movieVM: MovieViewModel = MovieViewModel()
    @State var textFieldMovieName: String=""
    var body: some View {
        NavigationView{
            VStack{
                TextField("Add movie name here...", text: $textFieldMovieName)
                    .font(.system(size: 20))
                    .foregroundColor(.white)
                    .frame(height: 55)
                    .background(Color(.gray))
                    .cornerRadius(10)
                    .padding(.horizontal)
                
                Button {
                    movieVM.addMovie(movieName: textFieldMovieName)
                    textFieldMovieName=""
                } label: {
                    Text("Enter")
                        .font(.system(size: 20))
                        .bold()
                        .foregroundColor(.white)
                        .frame(width: 200, height: 60)
                        .background(Color(.blue))
                        .cornerRadius(10)
                }
               /* Button("SUBMIT") {
                    movieVM.addMovie(movieName: textFieldMoviename)
                }*/

                Spacer()
                
                List{
                    ForEach(movieVM.savedMoviesArray) { movie in
                        Text(movie.name ?? "Empty")
                    }.onDelete(perform: movieVM.deleteMovie)
                        
                   
                }
                
            }.navigationTitle("Movies")
        }
            
            
        }
    }


struct MovieList_Previews: PreviewProvider {
    static var previews: some View {
       MovieList()
    }
}
