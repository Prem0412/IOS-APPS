//
//  BudgetTrackerHome.swift
//  BudgetTracker
//
//  Created by admin on 28/01/25.
//

import SwiftUI

struct BudgetTrackerHomeView : View{
    
    var body: some View{
        NavigationView{
            
            
            
            
        }
        
    }
}

struct BudgetTrackerHome_Previre: PreviewProvider{
    
    static var previews: some View{
        
        BudgetTrackerHomeView()
    }
}
