//
//  ContentView.swift
//  Basics
//
//  Created by admin on 30/01/25.
//

import SwiftUI

struct FruitModel: Identifiable {
    var id:String = UUID().uuidString
    var name:String
    var count: Int
    
}

class FruitViewModel : ObservableObject{
    @Published var fruitArray: [FruitModel] = []
    
    init(){ getFruits() }
    
    func getFruits(){
        
        let fruit_1 = FruitModel(name:"Apple", count: 10)
        let fruit_2 = FruitModel(name:"Peach", count: 20)
        let fruit_3 = FruitModel(name: "Banana", count: 24)
        let fruit_4 = FruitModel(name:"Watermelon", count: 10)
        
        
        fruitArray.append(fruit_1)
        fruitArray.append(fruit_2)
        fruitArray.append(fruit_3)
        fruitArray.append(fruit_4)
        
    }
}

struct ContentView: View {
    
   @StateObject var fruitViewModel:FruitViewModel = FruitViewModel()// creating object of viewModelClass
    
    var body: some View {
        NavigationView
        {
            List
            {
                ForEach(fruitViewModel.fruitArray)
                { fruit in
                    HStack
                    {
                        Text(fruit.name).bold()
                        Text("\(fruit.count)").foregroundColor(.red)
                    }
                }.onDelete { index in
                    fruitViewModel.fruitArray.remove(atOffsets: index)
                }
                
            }.navigationTitle("Fruit List")
            
        }
            
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
