//
//  BasicsApp.swift
//  Basics
//
//  Created by admin on 30/01/25.
//

import SwiftUI

@main
struct BasicsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
