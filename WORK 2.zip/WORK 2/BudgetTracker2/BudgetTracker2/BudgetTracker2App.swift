//
//  BudgetTracker2App.swift
//  BudgetTracker2
//
//  Created by admin on 28/01/25.
//

import SwiftUI

@main
struct BudgetTracker2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
