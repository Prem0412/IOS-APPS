//
//  FitnessAppMileStoneApp.swift
//  FitnessAppMileStone
//
//  Created by admin on 04/02/25.
//

import SwiftUI

@main
struct FitnessAppMileStoneApp: App {

    let persistentController = PersistenceController.shared
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(\.managedObjectContext, persistentController.container.viewContext)
        }
    }
}
