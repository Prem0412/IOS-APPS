//
//  ContentView.swift
//  FitnessAppMileStone
//
//  Created by admin on 04/02/25.
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject(\.managedObjectContext
    )
    private var viewContext
    @State var workoutName: String=""
    @State var caloriesBurnt: String = ""
    @State var duration:String = ""
    
    
    var body: some View {
        
        NavigationView{
            
            VStack{
                
                TextField("Workout name", text: $workoutName)
                TextField("Calories Burnt", text: $caloriesBurnt).keyboardType(.decimalPad)
                TextField("Duration of workout", text: $duration).keyboardType(.decimalPad)
                Button("Save Workout", action: saveWorkout())
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
