//
//  TelemedicineAppApp.swift
//  TelemedicineApp
//
//  Created by admin on 15/02/25.
//

import SwiftUI

@main
struct TelemedicineAppApp: App {
  

    var body: some Scene {
        WindowGroup{
            ContentView()
               
        }
    }
}
