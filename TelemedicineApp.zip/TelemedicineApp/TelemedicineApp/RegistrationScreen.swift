//
//  RegistrationScreen.swift
//  TelemedicineApp
//
//  Created by admin on 15/02/25.
//

import SwiftUI
import CoreData

class RegisterViewModel: ObservableObject {
    // creating container for data
    let container : NSPersistentContainer
    
    
    
    // initializing data container
    init()
    {
        container = NSPersistentContainer(name : "TelemedicineApp")
        
        // checking if container is loaded or not
        container.loadPersistentStores
        {( description, error) in
            if let error = error
            {print("Error loading CoreData : \(error)")}
            else{ print("Successfully loaded core data!")}
        }
        
    }
    // requesting to fetch data of container
    func fetchMovie()
    {
        let request = NSFetchRequest<UserEntity>(entityName: "UserEntity")
        do{ try
            container.viewContext.fetch(request)
        }catch let error{
            print("ERROR FETCHING...\(error)")
        }
    }
    
    
    func addUser(phoneNumber:String, email:String, password:String){
        
        let newUser = UserEntity(context: container.viewContext)
        newUser.pnoneNumber = phoneNumber
        newUser.userEmail = email
        newUser.userPassword = password
        
    }
    
    
}

struct RegistrationScreen: View {
    
   @StateObject var vm = RegisterViewModel()
    @FetchRequest(entity: UserEntity.entity(), sortDescriptors: []) var user: FetchedResults<UserEntity>
   
    @State var email : String = ""
    @State var password: String = ""
    @State var phoneNumber: String = ""
     
    var body: some View {
          NavigationView {
            
            VStack{
                
                TextField("Phone Number", text: $phoneNumber)
                
                TextField("Email", text: $email)
                
                TextField("Password", text: $password)
                
                Button("Register") {
                    addUser(phoneNumber,email,password)
                  
                    
                   DashboardScreen()
                }.bold()
                    .foregroundColor(.white)
                .frame(width: 100, height: 40)
                    .background(Color(.blue))
                   
                
            }.padding(20)
            
          
        }.navigationTitle("Registration")

      }
    
    
}

struct RegistrationScreen_Previews: PreviewProvider {
    static var previews: some View {
        RegistrationScreen()
    }
}
