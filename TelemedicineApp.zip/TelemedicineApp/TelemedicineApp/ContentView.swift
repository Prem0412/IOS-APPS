//
//  ContentView.swift
//  TelemedicineApp
//
//  Created by admin on 15/02/25.
//

import SwiftUI
import CoreData


class contentViewModel: ObservableObject{
    
    
    // creating container for data
    let container : NSPersistentContainer
    
    
    
    // initializing data container
    init()
    {
        container = NSPersistentContainer(name : "TelemedicineApp")
        
        // checking if container is loaded or not
        container.loadPersistentStores
        {( description, error) in
            if let error = error
            {print("Error loading CoreData : \(error)")}
            else{ print("Successfully loaded core data!")}
        }
        
    }
    // requesting to fetch data of container
    func fetchMovie()
    {
        let request = NSFetchRequest<UserEntity>(entityName: "UserEntity")
        do{ try
            container.viewContext.fetch(request)
        }catch let error{
            print("ERROR FETCHING...\(error)")
        }
    }
    
    
    func addUser(){
        
        let newUser = UserEntity(context: container.viewContext)
    }
    
    
    }

struct ContentView: View{
    
   
   
    @FetchRequest(entity: UserEntity.entity(), sortDescriptors: [])
    var user: FetchedResults<UserEntity>
   
    @State var email : String = ""
    @State var password: String = ""

    var body: some View {
        NavigationView {
            
            VStack{
              
                
                TextField("Email", text: $email)
                
                TextField("Password", text: $password)
                Spacer()
                
                Button("LOGIN") {
                    RegistrationScreen()
                }.bold()
                    .foregroundColor(.white)
                    .frame(width: 100, height: 40)
                    .background(Color(.blue))
                   
                
            }.navigationTitle("Login ")
            
          
        }

  
   
    }
}



struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
